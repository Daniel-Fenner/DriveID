const db = require('../config/db');

class VeiculoRepository {
    async criar(placa, modelo, cor, id_motorista) {
        // INSERT INTO veiculo + id_motorista
        const query = 'INSERT INTO veiculo (placa, modelo, cor, id_motorista) VALUES ($1, $2, $3, $4) RETURNING *';
        const valores = [placa, modelo, cor, id_motorista];
        const resultado = await db.query(query, valores);
        return resultado.rows[0];
    }

    async listarTodos() {
        const resultado = await db.query('SELECT * FROM veiculo');
        return resultado.rows;
    }

    async buscarPorId(id_veiculo) {
        const query = 'SELECT * FROM veiculo WHERE id_veiculo = $1';
        const resultado = await db.query(query, [id_veiculo]);
        return resultado.rows[0];
    }

    async atualizar(id_veiculo, cor) {
        const query = 'UPDATE veiculo SET cor = $2 WHERE id_veiculo = $1 RETURNING *';
        const valores = [id_veiculo, cor];
        const resultado = await db.query(query, valores);
        return resultado.rows[0];
    }

    async deletar(id_veiculo) {
        const query = 'DELETE FROM veiculo WHERE id_veiculo = $1 RETURNING *';
        const resultado = await db.query(query, [id_veiculo]);
        return resultado.rows[0];
    }
}

module.exports = new VeiculoRepository();