const express = require('express');
const router = express.Router();
const veiculoController = require('../controllers/veiculoController');

router.post('/veiculos', veiculoController.criar);
router.get('/veiculos', veiculoController.listar);
router.put('/veiculos/:id', veiculoController.atualizar);
router.delete('/veiculos/:id', veiculoController.deletar);

module.exports = router;