const express = require('express');
const cors = require('cors');
require('dotenv').config();

const veiculoRoutes = require('./routes/veiculoRoutes');

const app = express();

// middlewares
app.use(cors());
app.use(express.json());

// rota
app.use('/api', veiculoRoutes);

// port
const PORT = process.env.PORT || 3333;
app.listen(PORT, () => {
    console.log(`Servidor a rodar na porta ${PORT}`);
});