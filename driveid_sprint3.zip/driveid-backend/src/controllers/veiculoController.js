const veiculoRepository = require('../repositories/veiculoRepository');

class VeiculoController {
    // CREATE (post)
    async criar(req, res) {
        try {
            const { placa, modelo, cor, id_motorista } = req.body;
            const novoVeiculo = await veiculoRepository.criar(placa, modelo, cor, id_motorista);
            res.status(201).json(novoVeiculo);
        } catch (erro) {
            res.status(500).json({ erro: 'Erro ao criar veículo', detalhe: erro.message });
        }
    }

    // READ (get)
    async listar(req, res) {
        try {
            const veiculos = await veiculoRepository.listarTodos();
            res.status(200).json(veiculos);
        } catch (erro) {
            res.status(500).json({ erro: 'Erro ao listar veículos' });
        }
    }

    // UPDATE (put)
    async atualizar(req, res) {
        try {
            const { id } = req.params;
            const { cor } = req.body;
            const veiculoAtualizado = await veiculoRepository.atualizar(id, cor);
            res.status(200).json(veiculoAtualizado);
        } catch (erro) {
            res.status(500).json({ erro: 'Erro ao atualizar veículo' });
        }
    }

    // DELETE (delete)
    async deletar(req, res) {
        try {
            const { id } = req.params;
            await veiculoRepository.deletar(id);
            res.status(200).json({ mensagem: 'Veículo removido com sucesso' });
        } catch (erro) {
            res.status(500).json({ erro: 'Erro ao deletar veículo' });
        }
    }
}

module.exports = new VeiculoController();