
// DRIVEID - SCRIPT DE GESTÃO DE VEÍCULOS

const STORAGE_KEY = '@DriveID:veiculos';
let veiculoEmEdicaoId = null;

document.addEventListener('DOMContentLoaded', () => {
    inicializarApp();
});

function inicializarApp() {
    const formCadastro = document.getElementById('form-cadastro');
    if (formCadastro) {
        formCadastro.addEventListener('submit', cadastrarMotorista);
    }

    const formLogin = document.getElementById('form-login');
    if (formLogin) {
        formLogin.addEventListener('submit', fazerLogin);
    }
    const formVeiculo = document.getElementById('form-veiculo');
    
    if (formVeiculo) {
        formVeiculo.addEventListener('submit', cadastrarVeiculo);
    }
    const formCartao = document.getElementById('form-cartao');
    if (formCartao) {
        formCartao.addEventListener('submit', cadastrarCartao);
        renderizarCartoes();
    }
    

    renderizarTabelaVeiculos();
    atualizarMenuNavegacao();
    renderizarHistorico();
    atualizarResumoDashboard();
}

// 1. VALIDAÇÃO DE PLACA (Antiga e Mercosul)
function validarPlacaBrasil(placa) {
    const placaLimpa = placa.trim().toUpperCase();
    
    const regexPlacaAntiga = /^[A-Z]{3}-[0-9]{4}$/;
    const regexPlacaMercosul = /^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$/;
    const regexPlacaAntigaSemHifen = /^[A-Z]{3}[0-9]{4}$/;

    return regexPlacaAntiga.test(placaLimpa) || 
           regexPlacaMercosul.test(placaLimpa) || 
           regexPlacaAntigaSemHifen.test(placaLimpa);
}

// 2. OPERAÇÕES DE CRUD (Vinculadas ao Usuário Logado e ao Banco de Dados)
async function obterVeiculos() {
    try {
        const resposta = await fetch('http://localhost:3333/api/veiculos');
        const todosVeiculos = await resposta.json();
        
        const sessao = JSON.parse(localStorage.getItem(SESSAO_ATUAL));
        if (!sessao) return [];
        
        return todosVeiculos.filter(v => v.id_motorista === parseInt(sessao.id));
    } catch (erro) {
        console.error('Erro ao buscar veículos:', erro);
        return [];
    }
}

async function cadastrarVeiculo(event) {
    event.preventDefault();

    const inputPlaca = document.getElementById('placa');
    const inputModelo = document.getElementById('modelo');
    const inputCor = document.getElementById('cor');

    const placa = inputPlaca.value.trim().toUpperCase();
    const modelo = inputModelo.value.trim();
    const cor = inputCor.value.trim();

    if (!placa || !modelo || !cor) {
        alert('Por favor, preencha todos os campos do veículo.');
        return;
    }

    if (!validarPlacaBrasil(placa)) {
        alert('Formato de placa inválido! Utilize o padrão antigo (ABC-1234) ou Mercosul (ABC1D23).');
        inputPlaca.focus();
        return;
    }

    const sessao = JSON.parse(localStorage.getItem(SESSAO_ATUAL));
    if (!sessao) {
        alert('Erro: Você precisa estar logado para cadastrar um veículo.');
        return;
    }

    const novoVeiculo = {
        placa: placa,
        modelo: modelo,
        cor: cor,
        id_motorista: parseInt(sessao.id)
    };

    try {
        const resposta = await fetch('http://localhost:3333/api/veiculos', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(novoVeiculo)
        });

        if (resposta.status === 201) {
            alert('Veículo cadastrado com sucesso!');
            event.target.reset();
            renderizarTabelaVeiculos();
        } else {
            alert('Erro ao cadastrar o veículo. Verifique se a placa já existe.');
        }
    } catch (erro) {
        console.error('Erro de conexão:', erro);
        alert('Não foi possível conectar ao servidor.');
    }
}

async function excluirVeiculo(id) {
    if (confirm('Tem certeza de que deseja remover este veículo?')) {
        try {
            const resposta = await fetch(`http://localhost:3333/api/veiculos/${id}`, {
                method: 'DELETE'
            });

            if (resposta.ok) {
                renderizarTabelaVeiculos();
            } else {
                alert('Erro ao excluir o veículo do banco de dados.');
            }
        } catch (erro) {
            console.error('Erro ao excluir:', erro);
        }
    }
}

// 3. RENDERIZAÇÃO DINÂMICA NO DOM
async function renderizarTabelaVeiculos() {
    const tbody = document.getElementById('lista-veiculos');
    if (!tbody) return;

    const veiculos = await obterVeiculos();
    tbody.innerHTML = '';

    if (veiculos.length === 0) {
        tbody.innerHTML = `<tr><td colspan="4" class="text-center text-warning py-3">Nenhum veículo registado até ao momento.</td></tr>`;
        return;
    }

    veiculos.forEach((veiculo) => {
        const tr = document.createElement('tr');
        const idDoVeiculo = veiculo.id || veiculo.id_veiculo; 

        tr.innerHTML = `
            <td class="text-warning fw-bold">${veiculo.placa}</td>
            <td>${veiculo.modelo}</td>
            <td>${veiculo.cor}</td>
            <td>
                <!-- NOVO BOTÃO DE EDITAR ADICIONADO AQUI -->
                <button class="btn btn-sm btn-outline-info px-3 me-2" onclick="prepararEdicaoVeiculo('${idDoVeiculo}', '${veiculo.placa}', '${veiculo.modelo}', '${veiculo.cor}')">Editar</button>
                <button class="btn btn-sm btn-outline-danger px-3" onclick="excluirVeiculo('${idDoVeiculo}')">Remover</button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function prepararEdicaoVeiculo(id, placa, modelo, cor) {
    document.getElementById('placa').value = placa;
    document.getElementById('modelo').value = modelo;
    document.getElementById('cor').value = cor;

    veiculoEmEdicaoId = id;

    const btnSubmit = document.querySelector('#form-veiculos button[type="submit"]') || document.querySelector('button[onclick*="cadastrarVeiculo"]');
    if (btnSubmit) {
        btnSubmit.innerText = 'Salvar Alterações';
    }
}

async function cadastrarVeiculo(event) {
    event.preventDefault();

    const inputPlaca = document.getElementById('placa');
    const inputModelo = document.getElementById('modelo');
    const inputCor = document.getElementById('cor');

    const placa = inputPlaca.value.trim().toUpperCase();
    const modelo = inputModelo.value.trim();
    const cor = inputCor.value.trim();

    if (!placa || !modelo || !cor) {
        alert('Por favor, preencha todos os campos do veículo.');
        return;
    }

    const sessao = JSON.parse(localStorage.getItem(SESSAO_ATUAL));
    if (!sessao) {
        alert('Erro: Você precisa estar logado.');
        return;
    }

    const dadosVeiculo = {
        placa: placa,
        modelo: modelo,
        cor: cor,
        id_motorista: parseInt(sessao.id)
    };

    try {
        let resposta;

        if (veiculoEmEdicaoId) {
            resposta = await fetch(`http://localhost:3333/api/veiculos/${veiculoEmEdicaoId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(dadosVeiculo)
            });
        } else {
            resposta = await fetch('http://localhost:3333/api/veiculos', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(dadosVeiculo)
            });
        }

        if (resposta.ok) {
            alert(veiculoEmEdicaoId ? 'Veículo atualizado com sucesso!' : 'Veículo cadastrado com sucesso!');
            
            event.target.reset();
            veiculoEmEdicaoId = null; 
            
            const btnSubmit = document.querySelector('#form-veiculos button[type="submit"]') || document.querySelector('button[onclick*="cadastrarVeiculo"]');
            if (btnSubmit) btnSubmit.innerText = 'Cadastrar Veículo';

            renderizarTabelaVeiculos();
        } else {
            alert('Erro ao salvar o veículo. Verifique se a placa já existe.');
        }
    } catch (erro) {
        console.error('Erro de conexão:', erro);
        alert('Não foi possível conectar ao servidor.');
    }
}

// ABA RESUMO (STATUS EM TEMPO REAL)
function atualizarResumoDashboard() {
    const containerResumo = document.getElementById('tab-resumo');
    if (!containerResumo) return;

    const sessao = JSON.parse(localStorage.getItem(SESSAO_ATUAL));
    if (!sessao) return;

    const ticket = JSON.parse(localStorage.getItem(`${TICKET_ATIVO}_${sessao.id}`));
    const alertBox = containerResumo.querySelector('.alert');

    if (ticket) {
        // Se houver um carro estacionado agora
        const dataEntrada = new Date(ticket.horaEntrada).toLocaleTimeString('pt-BR');
        alertBox.className = 'alert alert-success bg-dark border-success text-light';
        alertBox.innerHTML = `<strong>🟢 Estacionado:</strong> O seu veículo <strong>${ticket.placa}</strong> está no <strong>${ticket.local}</strong> desde as ${dataEntrada}.`;
    } else {
        // Se não houver nenhum carro estacionado
        alertBox.className = 'alert alert-secondary bg-black border-warning text-light';
        alertBox.innerHTML = `<strong>Status:</strong> Nenhum veículo seu está estacionado no momento.`;
    }
}

// MÓDULO DE AUTENTICAÇÃO (MOTORISTAS)
const DB_MOTORISTAS = '@DriveID:motoristas';
const SESSAO_ATUAL = '@DriveID:sessao';

function obterMotoristas() {
    const dados = localStorage.getItem(DB_MOTORISTAS);
    return dados ? JSON.parse(dados) : [];
}

// 1. CADASTRO DE MOTORISTA
function cadastrarMotorista(event) {
    event.preventDefault();

    const nome = document.getElementById('cad-nome').value.trim();
    const cpf = document.getElementById('cad-cpf').value.trim();
    const email = document.getElementById('cad-email').value.trim();
    const senha = document.getElementById('cad-senha').value.trim();

    const motoristas = obterMotoristas();

    const usuarioExistente = motoristas.find(m => m.email === email || m.cpf === cpf);
    if (usuarioExistente) {
        alert('Este CPF ou E-mail já está cadastrado em nosso sistema.');
        return;
    }

    const novoMotorista = {
        id: Date.now().toString(),
        nome,
        cpf,
        email,
        senha 
    };

    motoristas.push(novoMotorista);
    localStorage.setItem(DB_MOTORISTAS, JSON.stringify(motoristas));

    alert('Cadastro realizado com sucesso! Você já pode fazer login.');
    event.target.reset();
    
    document.getElementById('pills-login-tab').click();
}

// 2. LOGIN DE MOTORISTA
function fazerLogin(event) {
    event.preventDefault();

    const email = document.getElementById('login-email').value.trim();
    const senha = document.getElementById('login-senha').value.trim();

    const motoristas = obterMotoristas();

    const motoristaEncontrado = motoristas.find(m => m.email === email && m.senha === senha);

    if (motoristaEncontrado) {
        localStorage.setItem(SESSAO_ATUAL, JSON.stringify({
            id: 1, 
            nome: motoristaEncontrado.nome
        }));

        alert(`Bem-vindo(a) de volta, ${motoristaEncontrado.nome}!`);
        
        window.location.href = 'dashboard.html';
    } else {
        alert('E-mail ou senha incorretos. Tente novamente.');
    }
}
// DASHBOARD & PAGAMENTOS

function verificarAutenticacao() {
    const sessao = localStorage.getItem(SESSAO_ATUAL);
    
    if (!sessao && window.location.pathname.includes('dashboard.html')) {
        window.location.href = 'login.html';
        return;
    }

    if (sessao) {
        const usuario = JSON.parse(sessao);
        const saudacao = document.getElementById('saudacao-usuario');
        if (saudacao) {
            saudacao.innerText = `Olá, ${usuario.nome.split(' ')[0]}`; // Pega só o primeiro nome
        }
    }
}

function fazerLogout() {
    localStorage.removeItem(SESSAO_ATUAL);
    window.location.href = 'index.html';
}

function obterCartoes() {
    const sessao = JSON.parse(localStorage.getItem(SESSAO_ATUAL));
    if (!sessao) return [];
    
    const chave = `@DriveID:cartoes_${sessao.id}`;
    const dados = localStorage.getItem(chave);
    return dados ? JSON.parse(dados) : [];
}

function cadastrarCartao(event) {
    event.preventDefault();

    const numero = document.getElementById('cartao-numero').value.trim();
    const nome = document.getElementById('cartao-nome').value.trim().toUpperCase();
    const validade = document.getElementById('cartao-validade').value.trim();

    if (numero.length < 13) {
        alert('Número de cartão inválido.');
        return;
    }

    const cartoes = obterCartoes();
    
    const finalCartao = numero.slice(-4);

    const novoCartao = {
        id: Date.now().toString(),
        final: finalCartao,
        nome,
        validade
    };

    cartoes.push(novoCartao);
    
    const sessao = JSON.parse(localStorage.getItem(SESSAO_ATUAL));
    localStorage.setItem(`@DriveID:cartoes_${sessao.id}`, JSON.stringify(cartoes));

    event.target.reset();
    renderizarCartoes();
    alert('Cartão adicionado com sucesso!');
}

function excluirCartao(id) {
    if (confirm('Deseja remover este cartão da sua carteira?')) {
        let cartoes = obterCartoes();
        cartoes = cartoes.filter(c => c.id !== id);
        
        const sessao = JSON.parse(localStorage.getItem(SESSAO_ATUAL));
        localStorage.setItem(`@DriveID:cartoes_${sessao.id}`, JSON.stringify(cartoes));
        
        renderizarCartoes();
    }
}

function renderizarCartoes() {
    const divLista = document.getElementById('lista-cartoes');
    if (!divLista) return;

    const cartoes = obterCartoes();
    divLista.innerHTML = '';

    if (cartoes.length === 0) {
        divLista.innerHTML = '<p class="text-muted">Você não possui nenhum cartão cadastrado.</p>';
        return;
    }

    cartoes.forEach(cartao => {
        const col = document.createElement('div');
        col.className = 'col-md-6 col-lg-5 mb-3';
        
        col.innerHTML = `
            <div class="cartao-credito shadow-sm">
                <div class="d-flex justify-content-between align-items-center">
                    <span class="text-warning fw-bold">DriveID Pay</span>
                    <button class="btn btn-sm btn-outline-danger border-0" onclick="excluirCartao('${cartao.id}')" title="Remover Cartão">✖</button>
                </div>
                <div class="cartao-numero">
                    **** **** **** ${cartao.final}
                </div>
                <div class="cartao-detalhes">
                    <span>${cartao.nome}</span>
                    <span>${cartao.validade}</span>
                </div>
            </div>
        `;
        divLista.appendChild(col);
    });
}
function atualizarMenuNavegacao() {
    const areaAutenticacao = document.getElementById('menu-autenticacao');
    if (!areaAutenticacao) return;

    const sessao = localStorage.getItem(SESSAO_ATUAL);

    if (sessao) {
        areaAutenticacao.innerHTML = `<a href="dashboard.html" class="btn btn-warning fw-bold px-4">Meu Painel</a>`;
    } else {
        areaAutenticacao.innerHTML = `<a href="login.html" class="btn btn-warning fw-bold px-4">Entrar</a>`;
    }
}

const TICKET_ATIVO = '@DriveID:ticket_ativo';
const LOCAL_TEMP = '@DriveID:local_temp';

function prepararSimulador(nome, preco) {
    const sessao = localStorage.getItem(SESSAO_ATUAL);
    if (!sessao) {
        alert('Você precisa fazer login para usar os estacionamentos DriveID.');
        window.location.href = 'login.html';
        return;
    }
    
    localStorage.setItem(LOCAL_TEMP, JSON.stringify({ nome, preco }));
    window.location.href = 'simulador.html';
}

function carregarSimulador() {
    if (!window.location.pathname.includes('simulador.html')) return;

    verificarAutenticacao(); 

    const localData = JSON.parse(localStorage.getItem(LOCAL_TEMP));
    if (!localData) {
        window.location.href = 'index.html'; 
        return;
    }

    document.getElementById('sim-nome').innerText = localData.nome;
    document.getElementById('sim-preco').innerText = `R$ ${localData.preco.toFixed(2).replace('.', ',')}`;

    verificarTicketAtivo();
}

async function verificarTicketAtivo() {
    const sessao = JSON.parse(localStorage.getItem(SESSAO_ATUAL));
    const ticket = JSON.parse(localStorage.getItem(`${TICKET_ATIVO}_${sessao.id}`));

    const telaCheckin = document.getElementById('tela-checkin');
    const telaCheckout = document.getElementById('tela-checkout');

    if (ticket) {
        telaCheckin.classList.add('d-none');
        telaCheckout.classList.remove('d-none');
        document.getElementById('sim-placa-ativa').innerText = ticket.placa;
        
        const dataEntrada = new Date(ticket.horaEntrada);
        document.getElementById('sim-hora-entrada').innerText = dataEntrada.toLocaleTimeString('pt-BR');
    } else {
        telaCheckin.classList.remove('d-none');
        telaCheckout.classList.add('d-none');
        await carregarDropdownVeiculos();
    }
}

async function carregarDropdownVeiculos() {
    const veiculos = await obterVeiculos();
    const select = document.getElementById('sim-veiculo');
    
    select.innerHTML = '<option value="">Selecione a placa do carro...</option>';
    
    if (veiculos.length === 0) {
        select.innerHTML = '<option value="">Nenhum veículo cadastrado</option>';
        return;
    }

    veiculos.forEach(v => {
        const option = document.createElement('option');
        option.value = v.placa;
        option.innerText = `${v.placa} - ${v.modelo}`;
        select.appendChild(option);
    });
}

function fazerCheckIn() {
    const placaSelecionada = document.getElementById('sim-veiculo').value;
    if (!placaSelecionada) {
        alert('Selecione um veículo para entrar no estacionamento.');
        return;
    }

    const cartoes = obterCartoes();
    if (cartoes.length === 0) {
        alert('Cadastre um Cartão de Crédito no "Meu Painel" para poder usar a entrada automática.');
        return;
    }

    const localData = JSON.parse(localStorage.getItem(LOCAL_TEMP));
    const sessao = JSON.parse(localStorage.getItem(SESSAO_ATUAL));

    const ticket = {
        local: localData.nome,
        precoHora: localData.preco,
        placa: placaSelecionada,
        horaEntrada: new Date().getTime(), 
        cartaoId: cartoes[0].id, 
        finalCartao: cartoes[0].final
    };

    localStorage.setItem(`${TICKET_ATIVO}_${sessao.id}`, JSON.stringify(ticket));
    verificarTicketAtivo(); 
}

function fazerCheckOut() {
    const sessao = JSON.parse(localStorage.getItem(SESSAO_ATUAL));
    const ticket = JSON.parse(localStorage.getItem(`${TICKET_ATIVO}_${sessao.id}`));
    
    if (!ticket) return;

    const agora = new Date().getTime();
    const diferencaMs = agora - ticket.horaEntrada;
    
    let minutosSimulados = Math.floor(diferencaMs / 1000); 
    if (minutosSimulados < 60) minutosSimulados = 60; 

    const horasCobradas = Math.ceil(minutosSimulados / 60);
    const valorTotal = horasCobradas * ticket.precoHora;

    const recibo = {
        id: Date.now().toString(),
        data: new Date().toLocaleDateString('pt-BR'),
        local: ticket.local,
        placa: ticket.placa,
        tempo: `${horasCobradas} hora(s)`,
        valor: valorTotal,
        cartao: ticket.finalCartao
    };

    const chaveHistorico = `@DriveID:historico_${sessao.id}`;
    const historico = JSON.parse(localStorage.getItem(chaveHistorico)) || [];
    historico.push(recibo);
    localStorage.setItem(chaveHistorico, JSON.stringify(historico));

    // Remove ticket ativo
    localStorage.removeItem(`${TICKET_ATIVO}_${sessao.id}`);
    localStorage.removeItem(LOCAL_TEMP);

    alert(`Saída liberada!\n\nTempo: ${horasCobradas}h\nTotal cobrado: R$ ${valorTotal.toFixed(2).replace('.', ',')}\nCartão: final ${ticket.finalCartao}`);
    
    window.location.href = 'dashboard.html'; 
}
function renderizarHistorico() {
    const tbodyHistorico = document.getElementById('lista-historico');
    if (!tbodyHistorico) return; 

    const sessao = JSON.parse(localStorage.getItem(SESSAO_ATUAL));
    if (!sessao) return;

    const chaveHistorico = `@DriveID:historico_${sessao.id}`;
    const historico = JSON.parse(localStorage.getItem(chaveHistorico)) || [];

    if (historico.length === 0) {
        tbodyHistorico.innerHTML = `
            <tr>
                <td colspan="6" class="text-muted py-4">Você ainda não possui nenhum registo de estacionamento.</td>
            </tr>
        `;
        return;
    }

    tbodyHistorico.innerHTML = '';

    const historicoRecente = [...historico].reverse();

    historicoRecente.forEach(recibo => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${recibo.data}</td>
            <td class="fw-bold">${recibo.local}</td>
            <td><span class="badge bg-secondary fs-6">${recibo.placa}</span></td>
            <td>${recibo.tempo}</td>
            <td class="text-success fw-bold">R$ ${recibo.valor.toFixed(2).replace('.', ',')}</td>
            <td>**** ${recibo.cartao}</td>
        `;
        tbodyHistorico.appendChild(tr);
    });
}

